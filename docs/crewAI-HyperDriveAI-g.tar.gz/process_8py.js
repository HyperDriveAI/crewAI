var process_8py =
[
    [ "crewai.process.Process", "classcrewai_1_1process_1_1Process.html", "classcrewai_1_1process_1_1Process" ]
];