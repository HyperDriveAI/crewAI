var task_8py =
[
    [ "crewai.task.Task", "classcrewai_1_1task_1_1Task.html", "classcrewai_1_1task_1_1Task" ]
];