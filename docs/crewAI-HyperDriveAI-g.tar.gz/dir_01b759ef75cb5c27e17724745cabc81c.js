var dir_01b759ef75cb5c27e17724745cabc81c =
[
    [ "core-concepts", "dir_dd1f760a16f055d4842449584077cf39.html", null ],
    [ "how-to", "dir_5fc70bc23275b197f35a67c1ecc0ad9c.html", null ]
];