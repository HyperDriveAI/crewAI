var agent__tools__test_8py =
[
    [ "test_ask_question", "agent__tools__test_8py.html#ab227daa290ed4e8b0174747f05967af0", null ],
    [ "test_ask_question_to_wrong_agent", "agent__tools__test_8py.html#a3c90d61803806bd0b870952753229071", null ],
    [ "test_can_not_self_delegate", "agent__tools__test_8py.html#a14df1f5bc8f6c91734855b8789bbf79e", null ],
    [ "test_delegate_work", "agent__tools__test_8py.html#a4d022912b76ec2b2ae16cec949da1394", null ],
    [ "test_delegate_work_to_wrong_agent", "agent__tools__test_8py.html#a7585b1d33c0f59b587d5bae90f5e37f6", null ],
    [ "test_delegate_work_with_wrong_input", "agent__tools__test_8py.html#a61699832accafc5d08c08ab22d9b1693", null ],
    [ "researcher", "agent__tools__test_8py.html#a2b4dc9169d852bf1acaa0cf4989f00fe", null ],
    [ "tools", "agent__tools__test_8py.html#a46a8cc0d28214203676c3a2f3fcd8e73", null ]
];