var classcrewai_1_1process_1_1Process =
[
    [ "hierarchical", "classcrewai_1_1process_1_1Process.html#ad5d941504caaf4a99b8a1c017d0579d6", null ],
    [ "sequential", "classcrewai_1_1process_1_1Process.html#af8aa4eb7e51e8ee746d7b575c50f91c1", null ]
];