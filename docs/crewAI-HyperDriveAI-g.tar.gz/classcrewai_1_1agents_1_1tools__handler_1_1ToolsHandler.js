var classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler =
[
    [ "__init__", "classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler.html#a8521ab86de34665cc9f48f23db020fcd", null ],
    [ "on_tool_end", "classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler.html#ac902fba2479b00e49ccbc2706d80c38d", null ],
    [ "on_tool_start", "classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler.html#a78edc5a6e4bc8767fc7db64341cf4834", null ],
    [ "cache", "classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler.html#a5de03b60904d7704de1fab95b4c6543f", null ],
    [ "cache", "classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler.html#ac62fc1adc8fb1392ca280d3e32fefc78", null ],
    [ "last_used_tool", "classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler.html#aaa9ea0d7d90838817c36edc0e0ed7519", null ],
    [ "last_used_tool", "classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler.html#a7706edc128c28408cdeff5d9761468c9", null ]
];