var exceptions_8py =
[
    [ "crewai.agents.exceptions.TaskRepeatedUsageException", "classcrewai_1_1agents_1_1exceptions_1_1TaskRepeatedUsageException.html", "classcrewai_1_1agents_1_1exceptions_1_1TaskRepeatedUsageException" ]
];