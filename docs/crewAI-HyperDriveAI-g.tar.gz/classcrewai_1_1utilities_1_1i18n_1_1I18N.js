var classcrewai_1_1utilities_1_1i18n_1_1I18N =
[
    [ "errors", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html#a8cccc93240d5d6047195c04a306f16ea", null ],
    [ "load_translation", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html#ada134b1c0600c102b7cc85827671374d", null ],
    [ "retrieve", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html#a2f3ca7e4a835ed7045071a2136b23656", null ],
    [ "slice", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html#ae6f8e08d59bbdef7472b29707500d517", null ],
    [ "tools", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html#a2294cfae6e3e381433fe34ca3b215604", null ],
    [ "_translations", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html#a69b8f7b0a7e4f66783f81c23c81fbe57", null ],
    [ "_translations", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html#a02de04bed271f7e06d01763715d38cc8", null ],
    [ "language", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html#a8e1ed112311f04f0064676858f04376d", null ]
];