var hierarchy =
[
    [ "crewai.agents.cache.cache_handler.CacheHandler", "classcrewai_1_1agents_1_1cache_1_1cache__handler_1_1CacheHandler.html", null ],
    [ "crewai.agents.cache.cache_hit.CacheHit.Config", "classcrewai_1_1agents_1_1cache_1_1cache__hit_1_1CacheHit_1_1Config.html", null ],
    [ "crewai.agents.output_parser.CrewAgentOutputParser.Config", "classcrewai_1_1agents_1_1output__parser_1_1CrewAgentOutputParser_1_1Config.html", null ],
    [ "crewai.utilities.logger.Logger", "classcrewai_1_1utilities_1_1logger_1_1Logger.html", null ],
    [ "AgentExecutor", null, [
      [ "crewai.agents.executor.CrewAgentExecutor", "classcrewai_1_1agents_1_1executor_1_1CrewAgentExecutor.html", null ]
    ] ],
    [ "BaseCallbackHandler", null, [
      [ "crewai.agents.tools_handler.ToolsHandler", "classcrewai_1_1agents_1_1tools__handler_1_1ToolsHandler.html", null ]
    ] ],
    [ "BaseModel", null, [
      [ "crewai.agent.Agent", "classcrewai_1_1agent_1_1Agent.html", null ],
      [ "crewai.agents.cache.cache_hit.CacheHit", "classcrewai_1_1agents_1_1cache_1_1cache__hit_1_1CacheHit.html", null ],
      [ "crewai.crew.Crew", "classcrewai_1_1crew_1_1Crew.html", null ],
      [ "crewai.task.Task", "classcrewai_1_1task_1_1Task.html", null ],
      [ "crewai.tasks.task_output.TaskOutput", "classcrewai_1_1tasks_1_1task__output_1_1TaskOutput.html", null ],
      [ "crewai.tools.agent_tools.AgentTools", "classcrewai_1_1tools_1_1agent__tools_1_1AgentTools.html", null ],
      [ "crewai.tools.cache_tools.CacheTools", "classcrewai_1_1tools_1_1cache__tools_1_1CacheTools.html", null ],
      [ "crewai.utilities.i18n.I18N", "classcrewai_1_1utilities_1_1i18n_1_1I18N.html", null ],
      [ "crewai.utilities.prompts.Prompts", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html", null ],
      [ "crewai.utilities.rpm_controller.RPMController", "classcrewai_1_1utilities_1_1rpm__controller_1_1RPMController.html", null ]
    ] ],
    [ "Enum", null, [
      [ "crewai.process.Process", "classcrewai_1_1process_1_1Process.html", null ]
    ] ],
    [ "OutputParserException", null, [
      [ "crewai.agents.exceptions.TaskRepeatedUsageException", "classcrewai_1_1agents_1_1exceptions_1_1TaskRepeatedUsageException.html", null ]
    ] ],
    [ "ReActSingleInputOutputParser", null, [
      [ "crewai.agents.output_parser.CrewAgentOutputParser", "classcrewai_1_1agents_1_1output__parser_1_1CrewAgentOutputParser.html", null ]
    ] ],
    [ "str", null, [
      [ "crewai.process.Process", "classcrewai_1_1process_1_1Process.html", null ]
    ] ]
];