var classcrewai_1_1utilities_1_1prompts_1_1Prompts =
[
    [ "_build_prompt", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#ac0ce022b58f389e7cf8833f34dfc4fae", null ],
    [ "task_execution", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#a47c1ca533b23fa75df991be06531dafb", null ],
    [ "task_execution_with_memory", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#a2ad30bc1bbe08fdda0d6012c28d09599", null ],
    [ "task_execution_without_tools", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#a2f8a2b2694fca0e05e33c449125984a0", null ],
    [ "i18n", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#a8d5a233e7302e4c2a9a7fcbca788e495", null ],
    [ "SCRATCHPAD_SLICE", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#a5be3e2a906cbd0789ddec58c17d3ee87", null ],
    [ "SCRATCHPAD_SLICE", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#ac800fa069db5542eba544f798c9c9288", null ]
];