var prompts_8py =
[
    [ "crewai.utilities.prompts.Prompts", "classcrewai_1_1utilities_1_1prompts_1_1Prompts.html", "classcrewai_1_1utilities_1_1prompts_1_1Prompts" ]
];