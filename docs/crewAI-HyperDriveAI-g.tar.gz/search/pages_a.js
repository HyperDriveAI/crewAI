var searchData=
[
  ['readme_0',['README',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2README.html',1,'']]]
];
