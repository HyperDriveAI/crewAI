var searchData=
[
  ['managing_2dprocesses_2emd_0',['Managing-Processes.md',['../Managing-Processes_8md.html',1,'']]]
];
