var searchData=
[
  ['task_0',['Task',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2core-concepts_2Defining-Tasks.html',1,'Overview of a Task'],['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2core-concepts_2Creating-Tasks.html',1,'What is a Task?']]],
  ['to_20llms_1',['Connect CrewAI to LLMs',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2how-to_2LLM-Connections.html',1,'']]],
  ['tool_2',['What is a Tool?',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2core-concepts_2Agent-Tools.html',1,'']]]
];
