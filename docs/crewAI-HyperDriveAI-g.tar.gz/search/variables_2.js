var searchData=
[
  ['backstory_0',['backstory',['../classcrewai_1_1agent_1_1Agent.html#a4fd8e37c8bb553d2fb2b410a37d6ed1d',1,'crewai::agent::Agent']]]
];
