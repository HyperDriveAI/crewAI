var searchData=
[
  ['writer_0',['writer',['../namespacetests_1_1crew__test.html#a34a31fc9b9ea1b93edf8779e926477a3',1,'tests::crew_test']]]
];
