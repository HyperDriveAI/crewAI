var searchData=
[
  ['hit_5fcache_0',['hit_cache',['../classcrewai_1_1tools_1_1cache__tools_1_1CacheTools.html#ac5421b111f9174c07292be6d80863210',1,'crewai::tools::cache_tools::CacheTools']]]
];
