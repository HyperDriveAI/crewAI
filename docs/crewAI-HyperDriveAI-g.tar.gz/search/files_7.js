var searchData=
[
  ['i18n_2epy_0',['i18n.py',['../i18n_8py.html',1,'']]],
  ['index_2emd_1',['index.md',['../index_8md.html',1,'']]]
];
