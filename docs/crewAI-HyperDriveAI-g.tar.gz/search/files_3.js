var searchData=
[
  ['defining_2dtasks_2emd_0',['Defining-Tasks.md',['../Defining-Tasks_8md.html',1,'']]],
  ['delegation_2dand_2dcollaboration_2emd_1',['Delegation-and-Collaboration.md',['../Delegation-and-Collaboration_8md.html',1,'']]]
];
