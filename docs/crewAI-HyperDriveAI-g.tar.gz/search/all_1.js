var searchData=
[
  ['2_20setting_20up_20your_20crew_0',['2. Setting Up Your Crew',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2README.html#autotoc_md73',1,'']]],
  ['2_3a_20define_20the_20tasks_1',['Step 2: Define the Tasks',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2how-to_2Creating-a-Crew-and-kick-it-off.html#autotoc_md41',1,'']]]
];
