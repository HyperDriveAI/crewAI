var searchData=
[
  ['getting_2dstarted_2emd_0',['getting-started.md',['../getting-started_8md.html',1,'']]]
];
