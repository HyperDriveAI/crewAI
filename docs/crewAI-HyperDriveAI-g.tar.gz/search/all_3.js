var searchData=
[
  ['4_3a_20kick_20it_20off_0',['Step 4: Kick It Off',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2how-to_2Creating-a-Crew-and-kick-it-off.html#autotoc_md43',1,'']]]
];
