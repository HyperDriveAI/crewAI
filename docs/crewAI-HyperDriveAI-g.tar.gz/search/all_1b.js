var searchData=
[
  ['your_20agents_0',['Step 1: Assemble Your Agents',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2how-to_2Creating-a-Crew-and-kick-it-off.html#autotoc_md40',1,'']]],
  ['your_20crew_1',['2. Setting Up Your Crew',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2README.html#autotoc_md73',1,'']]],
  ['your_20crew_20to_20a_20model_2',['Connecting Your Crew to a Model',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2README.html#autotoc_md79',1,'']]],
  ['your_20own_20tools_3',['Creating your own Tools',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2core-concepts_2Agent-Tools.html#autotoc_md2',1,'']]]
];
