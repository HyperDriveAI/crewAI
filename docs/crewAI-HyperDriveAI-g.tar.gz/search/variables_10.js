var searchData=
[
  ['scratchpad_5fslice_0',['SCRATCHPAD_SLICE',['../classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#a5be3e2a906cbd0789ddec58c17d3ee87',1,'crewai.utilities.prompts.Prompts.SCRATCHPAD_SLICE'],['../classcrewai_1_1utilities_1_1prompts_1_1Prompts.html#ac800fa069db5542eba544f798c9c9288',1,'crewai.utilities.prompts.Prompts.SCRATCHPAD_SLICE']]],
  ['sequential_1',['sequential',['../classcrewai_1_1process_1_1Process.html#af8aa4eb7e51e8ee746d7b575c50f91c1',1,'crewai::process::Process']]],
  ['summary_2',['summary',['../classcrewai_1_1tasks_1_1task__output_1_1TaskOutput.html#a723e3e2e06ecc2a3ac82542db5cf5db6',1,'crewai.tasks.task_output.TaskOutput.summary'],['../classcrewai_1_1tasks_1_1task__output_1_1TaskOutput.html#a09710097772c461d8a93bf9049e1712e',1,'crewai.tasks.task_output.TaskOutput.summary']]]
];
