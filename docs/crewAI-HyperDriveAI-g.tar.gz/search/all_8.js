var searchData=
[
  ['define_20the_20tasks_0',['Step 2: Define the Tasks',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2how-to_2Creating-a-Crew-and-kick-it-off.html#autotoc_md41',1,'']]],
  ['defining_2dtasks_2emd_1',['Defining-Tasks.md',['../Defining-Tasks_8md.html',1,'']]],
  ['delegate_5fwork_2',['delegate_work',['../classcrewai_1_1tools_1_1agent__tools_1_1AgentTools.html#ac2685ccb3a19ca1d9b88069b41647ea2',1,'crewai::tools::agent_tools::AgentTools']]],
  ['delegation_3',['Implementing Collaboration and Delegation',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2core-concepts_2Delegation-and-Collaboration.html#autotoc_md21',1,'']]],
  ['delegation_20and_20autonomy_4',['Delegation and Autonomy',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2how-to_2Customizing-Agents.html#autotoc_md48',1,'']]],
  ['delegation_2dand_2dcollaboration_2emd_5',['Delegation-and-Collaboration.md',['../Delegation-and-Collaboration_8md.html',1,'']]],
  ['delegation_3a_20dividing_20to_20conquer_6',['Delegation: Dividing to Conquer',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2core-concepts_2Delegation-and-Collaboration.html#autotoc_md20',1,'']]],
  ['dependencies_7',['Installing Dependencies',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2README.html#autotoc_md82',1,'']]],
  ['description_8',['description',['../classcrewai_1_1task_1_1Task.html#af56a804ef435077cc68d48097e4d20e1',1,'crewai.task.Task.description'],['../classcrewai_1_1tasks_1_1task__output_1_1TaskOutput.html#a1937329fe32282c66c8a9ae978f454be',1,'crewai.tasks.task_output.TaskOutput.description']]],
  ['dividing_20to_20conquer_9',['Delegation: Dividing to Conquer',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2core-concepts_2Delegation-and-Collaboration.html#autotoc_md20',1,'']]],
  ['documentation_10',['Welcome to crewAI Documentation',['../md__2tmp_2github__repos__arch__doc__gen_2HyperDriveAI_2crewAI_2docs_2index.html#autotoc_md63',1,'']]]
];
