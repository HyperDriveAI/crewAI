var searchData=
[
  ['kickoff_0',['kickoff',['../classcrewai_1_1crew_1_1Crew.html#ac7fa33e73119e450b68cd49f3dda70f1',1,'crewai::crew::Crew']]]
];
