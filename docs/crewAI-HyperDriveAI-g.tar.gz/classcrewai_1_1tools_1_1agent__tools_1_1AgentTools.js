var classcrewai_1_1tools_1_1agent__tools_1_1AgentTools =
[
    [ "_execute", "classcrewai_1_1tools_1_1agent__tools_1_1AgentTools.html#a72b356439ca50e92f24c997827fbae52", null ],
    [ "ask_question", "classcrewai_1_1tools_1_1agent__tools_1_1AgentTools.html#a290f5c30711c7c9d1e907ad7d08c91aa", null ],
    [ "delegate_work", "classcrewai_1_1tools_1_1agent__tools_1_1AgentTools.html#ac2685ccb3a19ca1d9b88069b41647ea2", null ],
    [ "tools", "classcrewai_1_1tools_1_1agent__tools_1_1AgentTools.html#a8f75d1a8273fea9bc9cb1fe44970dcba", null ],
    [ "agents", "classcrewai_1_1tools_1_1agent__tools_1_1AgentTools.html#a77052bf7cf06cde84a3fe4724495f22b", null ],
    [ "i18n", "classcrewai_1_1tools_1_1agent__tools_1_1AgentTools.html#a21d424c8123ff7cc3d482a8a9da1999d", null ]
];