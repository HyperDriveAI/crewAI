var namespacecrewai_1_1task =
[
    [ "Task", "classcrewai_1_1task_1_1Task.html", "classcrewai_1_1task_1_1Task" ]
];