var namespacecrewai =
[
    [ "agent", "namespacecrewai_1_1agent.html", "namespacecrewai_1_1agent" ],
    [ "agents", "namespacecrewai_1_1agents.html", "namespacecrewai_1_1agents" ],
    [ "crew", "namespacecrewai_1_1crew.html", "namespacecrewai_1_1crew" ],
    [ "process", "namespacecrewai_1_1process.html", "namespacecrewai_1_1process" ],
    [ "task", "namespacecrewai_1_1task.html", "namespacecrewai_1_1task" ],
    [ "tasks", "namespacecrewai_1_1tasks.html", "namespacecrewai_1_1tasks" ],
    [ "tools", "namespacecrewai_1_1tools.html", "namespacecrewai_1_1tools" ],
    [ "utilities", "namespacecrewai_1_1utilities.html", "namespacecrewai_1_1utilities" ]
];