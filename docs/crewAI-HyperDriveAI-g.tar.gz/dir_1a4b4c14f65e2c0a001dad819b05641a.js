var dir_1a4b4c14f65e2c0a001dad819b05641a =
[
    [ "docs", "dir_01b759ef75cb5c27e17724745cabc81c.html", "dir_01b759ef75cb5c27e17724745cabc81c" ],
    [ "src", "dir_af70b7337b2785e52c8234492b9a4e8e.html", "dir_af70b7337b2785e52c8234492b9a4e8e" ],
    [ "tests", "dir_d59b4599f602ce90dd32f367f4272346.html", "dir_d59b4599f602ce90dd32f367f4272346" ]
];