var rpm__controller_8py =
[
    [ "crewai.utilities.rpm_controller.RPMController", "classcrewai_1_1utilities_1_1rpm__controller_1_1RPMController.html", "classcrewai_1_1utilities_1_1rpm__controller_1_1RPMController" ]
];