var namespaces_dup =
[
    [ "crewai", "namespacecrewai.html", "namespacecrewai" ],
    [ "tests", "namespacetests.html", "namespacetests" ]
];